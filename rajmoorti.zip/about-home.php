  <section class="about-section">
            <div class="auto-container">
                <p class="add-home-head-name">OUR CERTIFICATE</p>
                <div class="row no-gutters">
                    <div class="col-lg-6 col-md-12 col-sm-12">
                        <img src="images/certificate1.jpg" class="img-responsive">
                    </div>

                    <div class="image-column col-lg-6 col-md-12 col-sm-12">
                        <div class="">
                            <div class="image-box">
                                <img src="images/gallery10.jpg" class="img-responsive">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
   </section>