<?php
define('BASE_URL', 'https://rajanmaluujaarts.com/');
define('ADMIN_URL', BASE_URL . 'admin/');
define('UPLOAD_PATH', __DIR__ . '/../assets/uploads/');
define('DB_HOST', 'localhost');
define('DB_USER', 'viralqls_rajanarts');
define('DB_PASS', 'Raju@1008');
define('DB_NAME', 'viralqls_rajanmaluja');
define('RAZORPAY_KEY_ID', 'rzp_live_jAGVmgwqfTTrPH');
define('RAZORPAY_KEY_SECRET', 'eSUb2lRZwTlZhr7ZuFSp6GmW');
?>