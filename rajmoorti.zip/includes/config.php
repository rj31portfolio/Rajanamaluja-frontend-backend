<?php
define('BASE_URL', 'http://localhost/rajmoorti/');
define('ADMIN_URL', BASE_URL . 'admin/');
define('UPLOAD_PATH', __DIR__ . '/../assets/uploads/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'artifyhub');
define('RAZORPAY_KEY_ID', 'rzp_live_jAGVmgwqfTTrPH');
define('RAZORPAY_KEY_SECRET', 'eSUb2lRZwTlZhr7ZuFSp6GmW');
?>