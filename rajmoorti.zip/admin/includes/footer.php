    <footer>
        <p>&copy; <?php echo date('Y'); ?> Rajanmaluujaarts Admin. All rights reserved.</p>
    </footer>
</body>
</html>